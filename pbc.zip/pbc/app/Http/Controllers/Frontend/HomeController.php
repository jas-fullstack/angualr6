<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Http\Request;
use Session;
use Carbon\Carbon;

class HomeController extends Controller
{
    /****************************************************
    Created By : Sanjeev Kumar
    Date : 30-jan-2019
    Description : function to get client information.
    Return : Clients array 
    Parameters  : null
    *****************************************************/
    public function index()
    {
        $clients = DB::table('tblclient')
                        ->orderByRaw('ClientID DESC')
                        ->where('ClientFirstName','!=',null )
                        ->get();

        return view('Frontend/index',['clients' => $clients]);
    }
    /****************************************************
    Created By : Sanjeev Kumar
    Date : 30-jan-2019
    Description : Used to create new client id and redirect to add client page
    Return : id 
    Parameters  : ID
    *****************************************************/
    public function create_new_client_id()
    {
        $id = DB::table('tblclient')->insertGetId(
            ['ClientFirstName' => null ]
        );
     
        return redirect()->to('general/'.base64_encode($id));
    }
    /****************************************************
    Created By : Sanjeev Kumar
    Date : 30-jan-2019
    Description : Used to save and update client information..
    Return :    
    Parameters  : id
    *****************************************************/
    public function general(Request $request,$id = null)
    {
        $input = $request->all();
       
      
        if( $input)
        {
            
           $tot_count = count($input['month']['payment']);

           for($i = 0; $i < $tot_count; ++$i){
               $month_pay = $input['month']['payment'][$i];
               $from = $input['month']['from'][$i];
               $to =  $input['month']['to'][$i]; 
               $PayID =  $input['month']['PayID'][$i];
               
                $monthly_email_date = Carbon::now()->startOfMonth();
                
                $pay_id = $PayID;
                if($pay_id == ""){
                    $clients = DB::table('tblclientmonthlypayment')
                                  ->where('PayID', $pay_id  )
                                 ->first();
                    $data = array(
                                'Start_Month' => $from, 
                                'End_Month' =>$to,
                                'ClientID'=> base64_decode($id) , 
                                'Payment'=> $month_pay
                            );

                    $table = DB::table('tblclientmonthlypayment');
                    $table->insert( $data );
                    return DB::getPdo()->lastInsertId();
                }else{
                    $data = array(
                        'Start_Month' => $from, 
                        'End_Month' =>$to,
                        'ClientID'=> base64_decode($id) , 
                        'Payment'=> $month_pay
                    );
                    $table = DB::table('tblclientmonthlypayment');
                    $table->where('PayID', $pay_id);
                    $table->update( $data );
                   // return $pay_id;
                }
            
                DB::table('tblclient')
                ->where('ClientID', base64_decode($id))
               ->update( $input['general_details'] );
           }        
            DB::table('tblclient')
                         ->where('ClientID', base64_decode($id))
                        ->update( $input['general_details'] );
            die;
        }
        
        $tblclientmonthlypayment = DB::table('tblclientmonthlypayment')->where('ClientID',base64_decode($id))->get();
        $client = DB::table('tblclient')->where('ClientID',base64_decode($id))->first();
     
        return view('Frontend/general',['id'=> base64_decode($id),'client'=> $client, 'tblclientmonthlypayment'=> $tblclientmonthlypayment]);
    }
    public function delete_client(Request $request,$id = null){
        $client = DB::table('tblclient')->where('ClientID',base64_decode($id))->delete(); 
        Session::flash('alert-success', 'Client deleted successfully');
        return redirect('/');
    }
    public function creditor()
    {
        return view('Frontend/creditor');
    }
    public function strategy()
    {
        return view('Frontend/strategy');
    }
    public function funding()
    {
        return view('Frontend/funding');
    }
    public function scorecard()
    {
        return view('Frontend/scorecard');
    }
    public function payment()
    {
        return view('Frontend/payment');
    }
}
