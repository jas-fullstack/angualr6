-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2019 at 04:00 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pbc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblclient`
--

CREATE TABLE `tblclient` (
  `ClientID` int(11) NOT NULL,
  `ClientFirstName` varchar(100) DEFAULT NULL,
  `ClientLastName` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Phone` varchar(100) DEFAULT NULL,
  `AddressLine1` varchar(100) DEFAULT NULL,
  `AddressLine2` varchar(100) DEFAULT NULL,
  `City` varchar(100) DEFAULT NULL,
  `State` varchar(50) DEFAULT NULL,
  `Zipcode` varchar(20) DEFAULT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Strategy` varchar(50) DEFAULT NULL,
  `AgentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclient`
--

INSERT INTO `tblclient` (`ClientID`, `ClientFirstName`, `ClientLastName`, `Email`, `Phone`, `AddressLine1`, `AddressLine2`, `City`, `State`, `Zipcode`, `Date`, `Strategy`, `AgentID`) VALUES
(71, NULL, 'kumar', 'asd@gmail.com', '8023432', NULL, NULL, NULL, 'city', NULL, '2019-02-01 15:43:52', NULL, NULL),
(72, NULL, 'sdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-01 15:44:53', NULL, NULL),
(73, 'dsssd', 'lastname', 'abca@gmail.com', '42432', 'this is addres line 1', 'this is addres line 1', 'city', 'state', '119', '2019-02-01 17:19:26', NULL, NULL),
(74, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-01 17:36:08', NULL, NULL),
(76, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-01 18:11:17', NULL, NULL),
(83, 'test', NULL, NULL, NULL, 'addredd', 'addressine 2', 'mohali', 'oubjab', '323', '2019-02-02 17:33:04', NULL, NULL),
(85, 'sdf', 'sdf', 'sdf', 'sdf', NULL, NULL, NULL, NULL, NULL, '2019-02-02 17:44:23', NULL, NULL),
(86, 'ds', 'kl', 'j', 'k', 'JBJ', 'gdg', 'gd', 'd', 'gd', '2019-02-02 17:57:48', NULL, NULL),
(87, 'dsdss dsa', 'sdfdsf', 'abc@gmail.com', '123897', 'address line 1', 'address line 2', 'moina', 'sdf', 'sdf33333333', '2019-02-03 14:15:51', NULL, NULL),
(88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 16:35:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblclientcreditor`
--

CREATE TABLE `tblclientcreditor` (
  `CreditorID` int(11) NOT NULL,
  `ClientID` int(11) NOT NULL,
  `Creditor` varchar(100) DEFAULT NULL,
  `Balance` decimal(15,2) DEFAULT NULL,
  `Payment` decimal(15,2) DEFAULT NULL,
  `ReduceTo` decimal(15,2) DEFAULT NULL,
  `Defer` smallint(6) DEFAULT NULL,
  `Custom` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblclientcreditorrate`
--

CREATE TABLE `tblclientcreditorrate` (
  `RateID` int(11) NOT NULL,
  `CreditorID` int(11) NOT NULL,
  `Rate` decimal(2,2) NOT NULL,
  `Start_DT` date NOT NULL,
  `End_DT` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblclientmonthlypayment`
--

CREATE TABLE `tblclientmonthlypayment` (
  `PayID` int(11) NOT NULL,
  `ClientID` int(11) NOT NULL,
  `Payment` decimal(10,2) DEFAULT NULL,
  `Start_Month` varchar(100) DEFAULT NULL,
  `End_Month` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclientmonthlypayment`
--

INSERT INTO `tblclientmonthlypayment` (`PayID`, `ClientID`, `Payment`, `Start_Month`, `End_Month`) VALUES
(1, 83, '100.00', NULL, NULL),
(2, 83, NULL, NULL, NULL),
(3, 83, NULL, NULL, NULL),
(4, 83, '100.00', NULL, NULL),
(5, 83, '100.00', NULL, NULL),
(6, 83, '100.00', '800', NULL),
(7, 83, '100.00', '800', NULL),
(8, 83, NULL, NULL, NULL),
(9, 83, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblclient`
--
ALTER TABLE `tblclient`
  ADD PRIMARY KEY (`ClientID`);

--
-- Indexes for table `tblclientcreditor`
--
ALTER TABLE `tblclientcreditor`
  ADD PRIMARY KEY (`CreditorID`),
  ADD KEY `ClientID` (`ClientID`);

--
-- Indexes for table `tblclientcreditorrate`
--
ALTER TABLE `tblclientcreditorrate`
  ADD PRIMARY KEY (`RateID`),
  ADD KEY `CreditorID` (`CreditorID`);

--
-- Indexes for table `tblclientmonthlypayment`
--
ALTER TABLE `tblclientmonthlypayment`
  ADD PRIMARY KEY (`PayID`),
  ADD KEY `ClientID` (`ClientID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblclient`
--
ALTER TABLE `tblclient`
  MODIFY `ClientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `tblclientcreditor`
--
ALTER TABLE `tblclientcreditor`
  MODIFY `CreditorID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblclientcreditorrate`
--
ALTER TABLE `tblclientcreditorrate`
  MODIFY `RateID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblclientmonthlypayment`
--
ALTER TABLE `tblclientmonthlypayment`
  MODIFY `PayID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblclientcreditor`
--
ALTER TABLE `tblclientcreditor`
  ADD CONSTRAINT `TblClientCreditor_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `tblclient` (`ClientID`) ON DELETE CASCADE;

--
-- Constraints for table `tblclientcreditorrate`
--
ALTER TABLE `tblclientcreditorrate`
  ADD CONSTRAINT `TblClientCreditorRate_ibfk_1` FOREIGN KEY (`CreditorID`) REFERENCES `tblclientcreditor` (`CreditorID`) ON DELETE CASCADE;

--
-- Constraints for table `tblclientmonthlypayment`
--
ALTER TABLE `tblclientmonthlypayment`
  ADD CONSTRAINT `TblClientMonthlyPayment_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `tblclient` (`ClientID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
