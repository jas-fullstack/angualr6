// this is the id of the form
$("#client_form").submit(function(e,text_refrance) {
    //text_refrance.parent('td').closest('tr td:first').hide();

    var form = $(this);
    console.log(form);
    var url = form.attr('action');

    $.ajax({
           type: "POST",
           url: url,
           async:false,
           headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
           data: form.serialize(), // serializes the form's elements.
           success: function(data)
           {
              console.log(data) // show response from the php script.
              if(data != '')
              {
                text_refrance.closest('.textboxDiv').find('td:nth-child(1) .monthly_payment').val(data);
              }
               
           }
         });

    e.preventDefault(); // avoid to execute the actual submit of the form.
});

//$('#client_form input').keyup(function(){
    $(document).on('focusout','#client_form input',function(e){
        var text_refrance = $(this);
        if (e.which != 9){
            $("#client_form").trigger('submit',[text_refrance]);
        }
  
});
/**Monthly Payment  */
$(document).ready(function() {
            
    $(document).on('keydown','.add_row',function(e){  
        
            console.log($(this).parents('.parent_div').find('input').val());
                if (e.which == 9){
                    
                $(this).removeClass('add_row');
            

        $("table#last_pay").append('<tr class="textboxDiv"><td ><span class="show_error_em_txt"><span class="glyphicon glyphicon-remove"></span></span><input type="text" value="" tabindex="-1" name="month[PayID][]" class="monthly_payment" /></td><td><input class="without_brdr"  placeholder="Payment" name="month[payment][]" type="text"/></td><td><input class="without_brdr" placeholder="From" name="month[from][]" type="text"/></td><td><input placeholder="To" class="without_brdr date-picker add_row" name="month[to][]" type="text"/></td><td><button class="simple_del" tabindex="-1"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td></div></tr>');
        }  
     
        });
        
    

      $(document).on('click','.simple_del',function(){
 
             $(this).parents('tr').remove();
             $('tbody').find('tr:last td:eq(2) input').addClass('add_row');
        })
      
      $('.date-picker').datepicker( {
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,
        dateFormat: 'mm/y',
        onClose: function(dateText, inst) { 
            $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
        }
    });
    
   function chk_first_name(){
    if($(".first_name").val() != ''){
        $(".Monthly_Payment").show(500);
    }else{
        $(".Monthly_Payment").hide(500);
    }
   } 
   chk_first_name();
$('.first_name').change(function(){

    chk_first_name();
});


$(document).on('keyup','.textboxDiv td input.without_brdr',function(){
    var text1= $(this).closest('.textboxDiv').find('td:nth-child(2) input').val(); 
    var text2= $(this).closest('.textboxDiv').find('td:nth-child(3) input').val(); 
    var text3= $(this).closest('.textboxDiv').find('td:nth-child(4) input').val();
    if(text1=="" || text2==""||text3==""){
        $(this).closest('.textboxDiv').find('td:nth-child(1) span').show(500);
    }else{
        $(this).closest('.textboxDiv').find('td:nth-child(1) span').hide(500);
    }
});


}); 