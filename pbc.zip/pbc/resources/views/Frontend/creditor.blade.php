@extends('layouts.layout_with_sidebar')
@section('content')
<section class="main-sec">
	<div class="container-fluid">
	 	<div class="row">
	 		@include('Frontend.sidebar')
	 			<div class="col-md-7 col-sm-6 col-xs-12">
			<div class="content-main">
				<div class="row">
					<div class="col-sm-12">
						<div class="top_flex single_line">
							<span class="mn_hding">Creditor</span>
							<button class="add_it"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADD</button>
						</div>
						<div class="table-responsive for_mobile_view">
							<table class="table cus_cr_left">
							  <thead class="thead-dark">
								<tr>
								  <th scope="col" class="pd_left">Creditor</th>
								   <th scope="col">Balance</th>
								   <th scope="col">Payment</th>
								   <th scope="col">Reduce to</th>
								   <th scope="col">Defer</th>
								   <th scope="col" class="pd-rght">Custom</th>
								</tr>
							  </thead>
							  <tbody>
								<tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="pd-rght">
										<input type="text" class="fixed_wdth"/>
										<div class="right_drop">
											<button class="btn btn-secondary dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> 	<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
											</button>
											<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											  <a class="dropdown-item" href="#"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Star</a>
											  <a data-toggle="modal" data-target="#file-share-modal" class="dropdown-item" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
											  <a data-toggle="modal" data-target="#deleteModal" class="dropdown-item" href="#"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove</a>
											</div>
										</div>
									</td>
								</tr>
							  
							  <tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="pd-rght">
										<input type="text" class="fixed_wdth"/>
										<div class="right_drop">
											<button class="btn btn-secondary dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> 	<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
											</button>
											<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											  <a class="dropdown-item" href="#"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Star</a>
											  <a data-toggle="modal" data-target="#file-share-modal" class="dropdown-item" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
											  <a data-toggle="modal" data-target="#deleteModal" class="dropdown-item" href="#"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove</a>
											</div>
										</div>
									</td>
								</tr>
							  
							  <tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="pd-rght">
										<input type="text" class="fixed_wdth"/>
										<div class="right_drop">
											<button class="btn btn-secondary dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> 	<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
											</button>
											<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											  <a class="dropdown-item" href="#"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Star</a>
											  <a data-toggle="modal" data-target="#file-share-modal" class="dropdown-item" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
											  <a data-toggle="modal" data-target="#deleteModal" class="dropdown-item" href="#"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove</a>
											</div>
										</div>
									</td>
								</tr>
							  
							  <tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="pd-rght">
										<input type="text" class="fixed_wdth"/>
										<div class="right_drop">
											<button class="btn btn-secondary dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> 	<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
											</button>
											<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											  <a class="dropdown-item" href="#"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Star</a>
											  <a data-toggle="modal" data-target="#file-share-modal" class="dropdown-item" href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
											  <a data-toggle="modal" data-target="#deleteModal" class="dropdown-item" href="#"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove</a>
											</div>
										</div>
									</td>
								</tr>
							  </tbody>
							</table>
							</div>
					</div>
				</div>
			</div>	
 		</div>
		<div class="col-md-3 col-sm-3 col-xs-12">
			<div class="top_flex">
				<span class="mn_hding">Creditor Name<br>Rate of Interest</span>
				<button class="add_it"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADD</button>
			</div>
			<div class="table-responsive">
				<table class="dash_border on_credit">
					<thead>
						<tr>
							<td>Rate</td>
							<td>From</td>
							<td>To</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<input class="without_brdr" type="text">
							</td>
							<td>
								<input class="without_brdr" type="text">
							</td>
							<td>
								<input class="without_brdr" type="text">										
							</td>
							<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
						</tr>
						<tr>
							<td>
								<input class="without_brdr" type="text">
							</td>
							<td>
								<input class="without_brdr" type="text">
							</td>
							<td>
								<input class="without_brdr" type="text">										
							</td>
							<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
						</tr>
						<tr>
							<td>
								<input class="without_brdr" type="text">
							</td>
							<td>
								<input class="without_brdr" type="text">
							</td>
							<td>
								<input class="without_brdr" type="text">										
							</td>
							<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
 		</div>
 	</div>
</section>
@endsection