@extends('layouts.layout_with_sidebar')
@section('content')
<section class="main-sec">
	<div class="container-fluid">
	 	<div class="row">
	 		@include('Frontend.sidebar')
	 		<div class="col-md-5 col-sm-5 col-xs-12">
			<div class="content-main">
				<div class="row">
					<div class="col-sm-12">
						<div class="top_flex single_line">
							<span class="mn_hding">Funding</span>
							<button class="add_it"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADD</button>
						</div>
						<div class="table-responsive for_mobile_view">
							<table class="table">
							  <thead class="thead-dark">
								<tr>
								  <th scope="col" class="pd_left">Insured</th>
								   <th scope="col">Death Benefit</th>
								   <th scope="col">Issue date</th>
								   <th scope="col">Modal</th>
								   <th scope="col" class="pd-rght">Start Date</th>
								</tr>
							  </thead>
							  <tbody>
								<tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="">
										<input type="text" class="fixed_wdth"/>
										<button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
									</td>
								</tr>
							  
							  <tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="">
										<input type="text" class="fixed_wdth"/>
										<button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
										</div>
									</td>
								</tr>
							  
							  <tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="">
										<input type="text" class="fixed_wdth"/>
										<button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
									</td>
								</tr>
							  
							  <tr>
									<td class="pd_left">
										<span class="custop_check">
											<input type="checkbox" />
											<label></label>
										</span>
										<input type="text" class="fixed_wdth"/>
									</td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td><input type="text" class="fixed_wdth"/></td>
									<td class="">
										<input type="text" class="fixed_wdth"/>
										<button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
									</td>
								</tr>
							  </tbody>
							</table>
							</div>
					</div>
				</div>
			</div>	
 		</div>
		<div class="col-md-5 col-sm-4 col-xs-12">
			<div class="top_flex">
				<span class="mn_hding">Insured Name<br>Yearly Disbursement</span>
				<button class="add_it"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADD</button>
			</div>
			<div class="table-responsive">
						<table class="dash_border with_year">
							<thead>
								<tr>
									<td>Yr#</td>
									<td>Premium Deposite</td>
									<td>Total Net Cash Value</td>
									<td>Avail Loan Value</td>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<input class="without_brdr" type="text">
									</td>
									<td>
										<input class="without_brdr" type="text">
									</td>
									<td>
										<input class="without_brdr" type="text">										
									</td>
									<td><input class="without_brdr" type="text"><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
								</tr>
								<tr>
									<td>
										<input class="without_brdr" type="text">
									</td>
									<td>
										<input class="without_brdr" type="text">
									</td>
									<td>
										<input class="without_brdr" type="text">										
									</td>
									<td><input class="without_brdr" type="text"><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
								</tr>
								<tr>
									<td>
										<input class="without_brdr" type="text">
									</td>
									<td>
										<input class="without_brdr" type="text">
									</td>
									<td>
										<input class="without_brdr" type="text">										
									</td>
									<td><input class="without_brdr" type="text"><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
								</tr>
							</tbody>
						</table>
						</div>
		</div>
 		</div>
 	</div>
</section>
@endsection