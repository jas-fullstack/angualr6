<div class="col-md-2 col-sm-3 col-xs-12">
	<div class="side-menu">
		<ul>
			<li>
			<a class="" tabindex=-1  href="{{url('/general/')}}/{{$id}}">
				<span class="mnu_ico"><img src="{{ URL::asset('frontend/images/GeneralDetails.png') }}" alt="general"></span>General Detail
			</a>
		</li>
			<li>
			<a class="" tabindex=-1   href="{{url('/creditor')}}/{{$id}}"><span class="mnu_ico"><img src="{{ URL::asset('frontend/images/Creditor.png') }}" alt="Creditor"></span>Creditor</a>
		</li>
			<li>
			<a class="" tabindex=-1  href="{{url('/strategy')}}/{{$id}}"><span class="mnu_ico"><img src="{{ URL::asset('frontend/images/strategy.png') }}" alt="strategy"></span>Strategy</a>
		</li>
			<li>
			<a class="" tabindex=-1  href="{{url('/funding')}}/{{$id}}"><span class="mnu_ico"><img src="{{ URL::asset('frontend/images/Funding.png') }}" alt="Funding"></span>Funding</a>
		</li>
			<li>
			<a class="" tabindex=-1  href="{{url('/scorecard')}}/{{$id}}"><span class="mnu_ico"><img src="{{ URL::asset('frontend/images/Scorecard.png') }}" alt="Scorecard"></span>Scorecard</a>
		</li>
		<li>
			<a class="" tabindex=-1  href="{{url('/payment')}}/{{$id}}"><span class="mnu_ico"><img src="{{ URL::asset('frontend/images/time.png') }}" alt="general"></span>Payment Schedule</a>
		</li>
		</ul>
	</div>
</div>