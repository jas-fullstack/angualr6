<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Private Banking Concept</title>

    <!-- Bootstrap -->
     <link href="{{ URL::asset('frontend/css/bootstrap.min.css') }}" rel="stylesheet">
     <link href="{{ URL::asset('frontend/css/font-awesome.min.css') }}" rel="stylesheet">
     <link href="{{ URL::asset('frontend/css/style.css') }}" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
 <header>
 	<div class="container-fluid">
 	<div class="row">
 		<div class="col-md-2 col-sm-3 col-xs-12"><a class="logo" tabindex=-1  href="{{url('/')}}"> <img src="{{ URL::asset('frontend/images/logo.png') }}" /> </a> </div>
 		<div class="col-md-7 col-sm-6 col-xs-8">
			<h2 class="main_hdng">Financial Freedom Analysis tm<label>Client Name</label></h2>
        </div>
 		<div class="col-md-3 col-sm-3 col-xs-4 cus_top_mrgn">	
           <span class="mobile_menu"><i class="fa fa-bars" aria-hidden="true"></i></span>
		   <div class="cus_user_ico">
		   <a  tabindex=-1 class="profile-pic" href="#"><img src="{{ URL::asset('frontend/images/profile-pic.png') }}" /></a>
		   <div class="user_cus_prfile">
			<div class="user_img">
				<img src="{{ URL::asset('frontend/images/profile-pic.png') }}" />
				<span> user name</span>
			</div>
			<div class="user_lg">
				<a href="#">profile</a>
				<a href="#">logout</a>
			</div>
		   </div>
		   </div>
		</div>

 	    </div>	
 	</div>
 </header>

@yield('content')

<footer>
  <div class="container-fluid">
   <strong>Copyright &copy;</strong>. All rights reserved.
  </div>
</footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
    
 
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{{ URL::asset('frontend/js/bootstrap.min.js') }}"></script>
    <script src="{{ URL::asset('frontend/js/custom.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
    
    
  <script>
    $(document).ready(function(){
      $("span.mobile_menu i").on("click", function(){
        $(".side-menu").toggleClass("open");
      });
      $(".cus_user_ico").on("click",function(){
        $(".user_cus_prfile").toggleClass("open");
      });
    });
  </script>
  </body>
</html>