<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/','Frontend\HomeController@index');
Route::get('/general/{id}','Frontend\HomeController@general');
Route::get('/general','Frontend\HomeController@general');
Route::post('/general/{id}','Frontend\HomeController@general');
Route::get('/delete_client/{id}','Frontend\HomeController@delete_client');

Route::get('/create_id','Frontend\HomeController@create_new_client_id');
Route::get('/creditor','Frontend\HomeController@creditor');

Route::get('/strategy','Frontend\HomeController@strategy');
Route::get('/funding','Frontend\HomeController@funding');
Route::get('/scorecard','Frontend\HomeController@scorecard');
Route::get('/payment','Frontend\HomeController@payment');