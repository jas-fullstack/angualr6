<?php $__env->startSection('content'); ?>
<section class="main-sec">
	<div class="container-fluid">
	 	<div class="row">
	 		<?php echo $__env->make('Frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 		<div class="col-md-10 col-sm-9 col-xs-12">
				<div class="content-main">
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Payment Schedule</p>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Balance:</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Reduce To:</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="clear"></div>
						<div class="col-sm-6">
							<label class="full_labl">Rate:</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Base Payment:</label>
							<input class="cus_txt" type="text"/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<label class="full_labl">Months to Pay Off:</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Month Paid Off:</label>
							<input class="cus_txt" type="text"/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<label class="full_labl">Reduced To Goal:</label>
							<input class="cus_txt" type="text" placeholder="" />
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Total Interest:</label>
							<input class="cus_txt" type="text" placeholder="" />
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Monthly Schedule</p>
						</div>
						<div class="col-sm-12">
							<div class="table-responsive">
							<table class="dash_border">
								<thead>
									<tr>
										<td>No</td>
										<td>Month</td>
										<td>Snowball</td>
										<td>Additional</td>
										<td>xyz</td>
										<td>abc</td>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
								</tbody>
							</table>
							</div>
						</div> 	
					</div>
				</div>	
	 		</div>
 		</div>
 	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_with_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>