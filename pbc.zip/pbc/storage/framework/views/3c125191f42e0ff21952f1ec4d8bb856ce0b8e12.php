<?php $__env->startSection('content'); ?>
<section class="main-sec">
	<div class="container-fluid">
	 	<div class="row">
	 		<?php echo $__env->make('Frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 		<div class="col-md-10 col-sm-9 col-xs-12">
				<div class="content-main">
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">General Details</p>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">ID</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="col-sm-6">
						
						</div>
						<div class="clear"></div>
						<div class="col-sm-6">
							<label class="full_labl">First Name</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Last Name</label>
							<input class="cus_txt" type="text"/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Contact Details</p>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Phone</label>
							<input class="cus_txt" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Email</label>
							<input class="cus_txt" type="email"/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Address</p>
						</div>
						<div class="col-sm-6">
							<input class="cus_txt" type="text" placeholder="City" />
							<input class="cus_txt" type="text" placeholder="State" />
							<input class="cus_txt" type="text" placeholder="Zipcode" />
						</div>
						<div class="col-sm-6">
							<input class="cus_txt" type="text" placeholder="City" />
							<input class="cus_txt" type="text" placeholder="State" />
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Monthly Payment<button class="cus_bbtnz"><i class="fa fa-plus" aria-hidden="true"></i> Add</button></p>
						</div>
						<div class="col-sm-6">
							<div class="table-responsive">
							<table class="dash_border">
								<thead>
									<tr>
										<td>Payment</td>
										<td>From</td>
										<td>To</td>
										<td></td>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>										
										</td>
										<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
									</tr>
									<tr>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>										
										</td>
										<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
									</tr>
									<tr>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>										
										</td>
										<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
									</tr>
								</tbody>
							</table>
							</div>
						</div> 	
					</div>
				</div>	
	 		</div>	
 		</div>
 	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_with_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>