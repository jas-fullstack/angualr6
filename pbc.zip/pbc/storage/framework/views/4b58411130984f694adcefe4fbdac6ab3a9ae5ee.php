<?php $__env->startSection('content'); ?>
<section class="main-sec">
	<div class="container-fluid">
	 	<div class="row">
	 		<?php echo $__env->make('Frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 		<div class="col-md-10 col-sm-9 col-xs-12">
			<div class="content-main">
				<div class="row">
					<div class="col-sm-12">
						<div class="cus_drop">
							<label>Strategy</label>
							<select class="cus_optn">
								<option>Option 1</option>
								<option>Option 2</option>
								<option>Option 3</option>
								<option>Option 4</option>
								<option>Option 5</option>
								<option>Option 6</option>
								<option>Option 7</option>
							</select>
						</div>
						<div class="table-responsive for_mobile_view">
							<table class="table">
							  <thead class="thead-dark">
								<tr>
								  <th scope="col" class="">Creditor</th>
								   <th scope="col">Balance</th>
								   <th scope="col">Interest Paid</th>
								   <th scope="col">Months to pay off</th>
								   <th scope="col">Month paid off</th>
								   <th scope="col" class="">Met 1st Goal</th>
								</tr>
							  </thead>
                            <tbody>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
								</tr>
							</tbody>
							</table>
							</div>
					</div>
				</div>
			</div>	
 		</div>
 		</div>
 	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_with_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>