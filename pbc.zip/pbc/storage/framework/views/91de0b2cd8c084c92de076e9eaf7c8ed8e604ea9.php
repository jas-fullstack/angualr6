<?php $__env->startSection('content'); ?>
	<section class="main-sec">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-6">
				<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('alert-' . $msg)): ?>
    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?></p>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
					<div class="cus_fllx">
						<label class="hm_txt">My Clients</label>
						<button onclick="window.location.href='<?php echo url('/create_id'); ?>'" class="cus_bbtnz">New</button>
					</div>
					<form class="form-inline">
					  <i class="fa fa-search" aria-hidden="true"></i>
					  <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search"   id="search_field" aria-label="Search">
					</form>
					<div class="table-responsive for_mobile_view">
								<table class="table" id="myTable">
								  <thead class="thead-dark">
									<tr class="myHead">
									  <th scope="col" class="pd_left">Client</th>
									   <th scope="col">Email</th>
									   <th scope="col">Phone</th>
									   <th scope="col">Date</th>
									   <th scope="col" class=""></th>
									</tr>
								  </thead>
								  <tbody>
									 
								  <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							
									<tr>
										<td class="pd_left">
											<span class="custop_check">
												<input type="checkbox">
												<label></label>
											</span>
											<?php echo e($client->ClientFirstName); ?>

										</td>
										<td><?php echo e($client->Email); ?></td>
										<td><?php echo e($client->Phone); ?></td>
										<td><?php echo e($client->Date); ?></td>

										<td class="pd-rght">
											<div class="right_drop">
												<button class="btn btn-secondary dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> 	<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
												</button>
												<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
												  <a class="dropdown-item" href="#"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Star</a>
												  <a href="<?php echo e(url('/general/')); ?>/<?php echo e(base64_encode($client->ClientID)); ?>" data-toggle="modal"  class="dropdown-item" ><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
												  <a data-toggle="modal" id="<?php echo e(base64_encode($client->ClientID)); ?>"  class="dropdown-item ask_delete" href="#"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove</a>
												</div>
											</div>
										</td>
									</tr>
										
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


									<!--tr class="hide_score for_mb_only">
										<td colspan="5">
											<div class="text-center bg_blck">
												scorecard
											</div>
											<div class="table-reponsive">
												<table class="spl_table">
													<thead>
														<tr>
															<th class="no_bordr"></th>
															<th colspan="2" class="brdr_right">DEPT FREE IN....</th>
															<th colspan="3">SHOW ME THE MONEY....</th>
														</tr>
														<tr>
															<th class="no_bordr"></th>
															<th>Months</th>
															<th class="brdr_right">Years</th>
															<th>Total Interest $</th>
															<th>Value of Interest</th>
															<th>Total $ Paid</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td><span class="red">Current Financial Path</span></td>
															<td>263</td>
															<td class="brdr_right">22</td>
															<td>$1,99,123</td>
															<td>56%</td>
															<td>$5,78,976</td>
														</tr>
														<tr>
															<td><span class="yellow">Private Banking Concept</span></td>
															<td>43</td>
															<td class="brdr_right">5</td>
															<td>$99,123</td>
															<td>9.6%</td>
															<td>$3,54,976</td>
														</tr>
														<tr>
															<td><span class="yellow">Private Banking Savings</span></td>
															<td>221</td>
															<td>18</td>
															<td>$1,87,123</td>
															<td>46.6%</td>
															<td>$1,64,124</td>
														</tr>
													</tbody>
												</table>
											</div>
										</td>
									</tr-->
								  
								</tbody>
								</table>
								</div>
				</div>
				<div class="col-sm-6 for_dk_only">
					<div class="cus_fllx">
						<label class="hm_txt">Client Name</label>
						<button class="cus_bbtnz"><i class="fa fa-upload" aria-hidden="true"></i> Export</button>
					</div>
					<div class="text-center bg_blck">
						scorecard
					</div>
					<div class="table-responsive">
						<table class="spl_table">
							<thead>
								<tr>
									<th class="no_bordr"></th>
									<th colspan="2" class="brdr_right">DEPT FREE IN....</th>
									<th colspan="3">SHOW ME THE MONEY....</th>
								</tr>
								<tr>
									<th class="no_bordr"></th>
									<th>Months</th>
									<th class="brdr_right">Years</th>
									<th>Total Interest $</th>
									<th>Value of Interest</th>
									<th>Total $ Paid</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><span class="red">Current Financial Path</td>
									<td>263</td>
									<td  class="brdr_right">22</td>
									<td>$1,99,123</td>
									<td>56%</td>
									<td>$5,78,976</td>
								</tr>
								<tr>
									<td><span class="yellow">Private Banking Concept</td>
									<td>43</td>
									<td  class="brdr_right">5</td>
									<td>$99,123</td>
									<td>9.6%</td>
									<td>$3,54,976</td>
								</tr>
								<tr>
									<td><span class="yellow">Private Banking Savings</td>
									<td>221</td>
									<td>18</td>
									<td>$1,87,123</td>
									<td>46.6%</td>
									<td>$1,64,124</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.home_page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>