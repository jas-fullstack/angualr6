<?php $__env->startSection('content'); ?>
<section class="main-sec">
	<div class="container-fluid">
	 	<div class="row">
	 		<?php echo $__env->make('Frontend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 		<div class="col-md-10 col-sm-9 col-xs-12">
				<div class="content-main">
					<div class="row">
						<div class="col-sm-12">
							<div class="text-center bg_blck">
								scorecard
							</div>
							<div class="table-reponsive">
								<table class="spl_table">
									<thead>
										<tr>
											<th class="no_bordr"></th>
											<th colspan="2" class="brdr_right">DEPT FREE IN....</th>
											<th colspan="3">SHOW ME THE MONEY....</th>
										</tr>
										<tr>
											<th class="no_bordr"></th>
											<th>Months</th>
											<th  class="brdr_right">Years</th>
											<th>Total Interest $</th>
											<th>Value of Interest</th>
											<th>Total $ Paid</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td><span class="red">Current Financial Path</td>
											<td>263</td>
											<td  class="brdr_right">22</td>
											<td>$1,99,123</td>
											<td>56%</td>
											<td>$5,78,976</td>
										</tr>
										<tr>
											<td><span class="yellow">Private Banking Concept</td>
											<td>43</td>
											<td  class="brdr_right">5</td>
											<td>$99,123</td>
											<td>9.6%</td>
											<td>$3,54,976</td>
										</tr>
										<tr>
											<td><span class="yellow">Private Banking Savings</td>
											<td>221</td>
											<td>18</td>
											<td>$1,87,123</td>
											<td>46.6%</td>
											<td>$1,64,124</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<img src="<?php echo e(URL::asset('frontend/images/p2.jpg')); ?>" alt="pie chart">
						</div>
						<div class="col-sm-6">
							<img src="<?php echo e(URL::asset('frontend/images/p1.jpg')); ?>" alt="pie chart">
						</div>
					</div>
				</div>	
	 		</div>
 		</div>
 	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_with_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>