<?php $__env->startSection('content'); ?>
<section class="main-sec">

	<div class="container-fluid">
	 	<div class="row">
	 		<?php echo $__env->make('Frontend.sidebar',['id'=> base64_encode($id)], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 		<div class="col-md-10 col-sm-9 col-xs-12">
			 <form action="" method="post" id="client_form">
				<div class="content-main">
				
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">General Details</p>
						</div>
					
						<div class="col-sm-6">
							<label class="full_labl">ID</label>
							<input class="cus_txt" value="<?php echo e($id); ?>" type="text" disabled/>
						</div>
						<div class="col-sm-6">
						
						</div>
						<div class="clear"></div>
						<div class="col-sm-6">
							<label class="full_labl">First Name</label>
							<input class="cus_txt first_name" tabindex="1" require value="<?php if(isset($client)): ?><?php echo e($client->ClientFirstName); ?><?php endif; ?>"  name="general_details[ClientFirstName]" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Last Name</label>
							<input class="cus_txt" name="general_details[ClientLastName]" tabindex="2" value="<?php if(isset($client)): ?><?php echo e($client->ClientLastName); ?><?php endif; ?>" type="text"/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Contact Details</p>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Phone</label>
							<input class="cus_txt" name="general_details[Phone]" tabindex="3" value="<?php if(isset($client)): ?><?php echo e($client->Phone); ?><?php endif; ?>" type="text"/>
						</div>
						<div class="col-sm-6">
							<label class="full_labl">Email</label>
							<input class="cus_txt" name="general_details[Email]" tabindex="4" value="<?php if(isset($client)): ?><?php echo e($client->Email); ?><?php endif; ?>" type="email"/>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<p class="dash_hdng">Address</p>
						</div>
						<div class="col-sm-6">
							<input class="cus_txt" type="text" tabindex="5" value="<?php if(isset($client)): ?><?php echo e($client->AddressLine1); ?><?php endif; ?>" name="general_details[AddressLine1]" placeholder="Address Line 1" name="Address Line 1" placeholder="City" />
							<input class="cus_txt" type="text" value="<?php if(isset($client)): ?><?php echo e($client->City); ?><?php endif; ?>" name="general_details[city]" tabindex="7" placeholder="city" />
							<input class="cus_txt" type="text" value="<?php if(isset($client)): ?><?php echo e($client->Zipcode); ?><?php endif; ?>" name="general_details[Zipcode]" tabindex="9" placeholder="Zipcode" />
						</div>
						<div class="col-sm-6">
							<input class="cus_txt" type="text" tabindex="6" value="<?php if(isset($client)): ?><?php echo e($client->AddressLine2); ?><?php endif; ?>" name="general_details[AddressLine2]"  placeholder="Address Line 2" />
							<input class="cus_txt" type="text" tabindex="8" value="<?php if(isset($client)): ?><?php echo e($client->State); ?><?php endif; ?>" name="general_details[state]"  placeholder="State" />
						</div>
					</div>
				
					<div style="display:none" class="row Monthly_Payment">
						<div class="col-sm-12">
							<p class="dash_hdng">Monthly Payment
								<!--button class="cus_bbtnz">
								<i class="fa fa-plus" aria-hidden="true"></i> Add</button--></p>
						</div>
						<div class="col-sm-6">
							<div class="table-responsive">
							<table class="dash_border" id="last_pay">
								<thead>
									<tr>
									<td></td>
										<td>Payment</td>
										<td>From</td>
										<td>To</td>
										<td></td>
									</tr>
								</thead>
								
								<tbody>

								<!--div class="textboxDiv">
								<div class="parent_div"><br>
									<input type='text'    />
									<input type='text'    />
									<input type='text'  class="last_text_box add_row" />
										
									<br>
								</div-->

								<?php $__currentLoopData = $tblclientmonthlypayment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mont_pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="textboxDiv">
										<td><span style="display:none"  class="show_error_em_txt"> <span class="glyphicon glyphicon-remove"></span></span>
									<input type="text" value="<?php echo e($mont_pay->PayID); ?>"  tabindex="-1" name="month[PayID][]" class="monthly_payment" />
									</td>
										<!--div class="parent_div"-->
											<td>
												<input class="without_brdr" tabindex=10 name="month[payment][]" value="<?php echo e($mont_pay->Payment); ?>" placeholder="Payment" type="text"/>
											</td>
											<td>
												<input class="without_brdr " tabindex=11 name="month[from][]"   placeholder="From" type="text"/>
											</td>
											<td>
												<input class="without_brdr add_row " tabindex=12 name="month[to][]"    placeholder="To" type="text"/>										
											</td>
											<td>
												
												<button class="simple_del" tabindex="-1"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
											</td>
										<!--/div-->
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr class="textboxDiv">
										<td><span style="display:none" class="show_error_em_txt"> <span class="glyphicon glyphicon-remove"></span></span>
									<input type="text" value="" tabindex="-1" name="month[PayID][]" class="monthly_payment" />
									</td>
										<!--div class="parent_div"-->
											<td>
												<input class="without_brdr" tabindex=10 name="month[payment][]" placeholder="Payment" type="text"/>
											</td>
											<td>
												<input class="without_brdr " tabindex=11 name="month[from][]"  placeholder="From" type="text"/>
											</td>
											<td>
												<input class="without_brdr add_row " tabindex=12 name="month[to][]" placeholder="To" type="text"/>										
											</td>
											<td>
												
												<button class="simple_del" tabindex="-1"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
											</td>
										<!--/div-->
									</tr>
									<!--tr>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>										
										</td>
										<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
									</tr>
									<tr>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>
										</td>
										<td>
											<input class="without_brdr" type="text"/>										
										</td>
										<td><button class="simple_del"><i class="fa fa-trash-o" aria-hidden="true"></i></button></td>
									</tr-->
								</tbody>
							</table>
							</div>
						</div> 	
					</div>
				</div>	
	 		</div>	
			 </form>
 		</div>
 	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_with_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>